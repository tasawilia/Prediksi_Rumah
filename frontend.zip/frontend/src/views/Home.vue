<!-- eslint-disable vue/multi-word-component-names  -->

<template>

 <div class="content background-page">
    <div class="home-header text-center py-4">
      <img src="/assets/img/LogoApk.png" alt="EstiHome Logo" class="home-logo mb-2" style="height: 60px;" />
      <h2 class="fw-bold mb-1" style="color: #6E9489;">EstiHome</h2>
      <div class="mb-3" style="font-size: 1.1rem; color: #444;">Sistem Prediksi Harga Rumah di Tangerang</div>
    </div>
    <div class="container">

      <!-- ROW 1: Harga Minimum dan Maksimum -->
      <div class="row gx-0">
        <!-- Harga Minimum -->
        <div class="col-md-6 mb-4">
          <div class="card h-100 shadow">
            <div class="bg-light p-3 border-bottom text-center">
              <div class="d-flex align-items-center justify-content-center">
                <i class="fas fa-coins me-2" style="font-size: 25px; color: #6E9489;"></i>
                <h5 class="text-uppercase fw-bold ml-3 mb-0">Harga Minimum</h5>
              </div>
              <h6 class="mb-0">Rp125 Juta</h6>
              <small class="text-muted">Daerah: Sepatan</small>
            </div>
            <div class="card-body d-flex flex-column align-items-center text-center">
              <!-- Carousel Minimum -->
              <div id="carouselMinimum" class="carousel slide position-relative w-100 mb-3" data-bs-ride="false">
                <div class="carousel-inner rounded-3">
                  <div class="carousel-item active"><img src="/assets/img/terendah1.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/terendah2.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/terendah3.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/terendah4.jpg" class="carousel-image d-block mx-auto"></div>
                </div>
                <button class="carousel-control-prev custom-carousel-arrow" type="button" data-bs-target="#carouselMinimum" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon small" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next custom-carousel-arrow" type="button" data-bs-target="#carouselMinimum" data-bs-slide="next">
                  <span class="carousel-control-next-icon small" aria-hidden="true"></span>
                </button>
              </div>
              <!-- Detail Minimum -->
              <div class="w-100 px-5 text-start">
                <div class="row mb-2">
                  <div class="col-6"><p class="mb-1"><strong>Tipe:</strong> Rumah</p></div>
                  <div class="col-6 ps-5"><p class="mb-1"><strong>Lantai:</strong> 1</p></div>
                </div>
                <div class="row">
                  <div class="col-6"><p class="mb-1"><strong>Luas Bangunan:</strong> 36 m²</p></div>
                  <div class="col-6 ps-5"><p class="mb-1"><strong>Luas Tanah:</strong> 60 m²</p></div>
                </div>
                <div class="row mt-2">
                  <div class="col-12">
                    <p class="mb-1"><strong>Fasilitas:</strong></p>
                    <ul class="mb-0 ps-3"><li>Keamanan 24 Jam</li></ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Harga Maksimum -->
        <div class="col-md-6 mb-4">
          <div class="card h-100 shadow">
            <div class="bg-light p-3 border-bottom text-center">
              <div class="d-flex align-items-center justify-content-center">
                <i class="fas fa-coins me-2" style="font-size: 25px; color: #6E9489;"></i>
                <h5 class="text-uppercase fw-bold ml-3 mb-0">Harga Maksimum</h5>
              </div>
              <h6 class="mb-0">Rp8,25 M</h6>
              <small class="text-muted">Daerah: BSD City</small>
            </div>
            <div class="card-body d-flex flex-column align-items-center text-center">
              <!-- Carousel Maksimum -->
              <div id="carouselMaximum" class="carousel slide position-relative w-100 mb-3" data-bs-ride="false">
                <div class="carousel-inner rounded-3">
                  <div class="carousel-item active"><img src="/assets/img/tertinggi4.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/tertinggi1.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/tertinggi2.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/tertinggi3.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/tertinggi5.jpg" class="carousel-image d-block mx-auto"></div>
                </div>
                <button class="carousel-control-prev custom-carousel-arrow" type="button" data-bs-target="#carouselMaximum" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon small" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next custom-carousel-arrow" type="button" data-bs-target="#carouselMaximum" data-bs-slide="next">
                  <span class="carousel-control-next-icon small" aria-hidden="true"></span>
                </button>
              </div>
              <!-- Detail Maksimum -->
              <div class="w-100 px-5 text-start">
                <div class="row mb-2">
                  <div class="col-6"><p class="mb-1"><strong>Tipe:</strong> Rumah</p></div>
                  <div class="col-6 ps-5"><p class="mb-1"><strong>Lantai:</strong> 3</p></div>
                </div>
                <div class="row">
                  <div class="col-6"><p class="mb-1"><strong>Luas Bangunan:</strong> 750 m²</p></div>
                  <div class="col-6 ps-5"><p class="mb-1"><strong>Luas Tanah:</strong> 450 m²</p></div>
                </div>
                <div class="row mt-2">
                  <div class="col-12">
                    <p class="mb-1"><strong>Fasilitas:</strong></p>
                    <ul class="mb-0 ps-3"><li>Kitchen Set</li></ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ROW 2: Harga Rata-rata dan Daerah Termahal -->
      <div class="row gx-0">
        <!-- Harga Rata-rata -->
        <div class="col-md-6 mb-4">
          <div class="card h-100 shadow">
            <div class="bg-light p-3 border-bottom text-center">
              <div class="d-flex align-items-center justify-content-center">
                <i class="fas fa-coins me-2" style="font-size: 25px; color: #6E9489;"></i>
                <h5 class="text-uppercase fw-bold ml-3 mb-0">Harga Rata-Rata</h5>
              </div>
              <h6 class="mb-0">Rp2,52 M</h6>
              <small class="text-muted">Seluruh Daerah Tangerang</small>
            </div>
            <div class="card-body d-flex flex-column align-items-center text-center">
              <div id="carouselRata" class="carousel slide position-relative w-100 mb-3" data-bs-ride="false">
                <div class="carousel-inner rounded-3">
                  <div class="carousel-item active"><img src="/assets/img/gaser1.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/gaser2.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/gaser3.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/gaser4.jpg" class="carousel-image d-block mx-auto"></div>
                </div>
                <button class="carousel-control-prev custom-carousel-arrow" type="button" data-bs-target="#carouselRata" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon small" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next custom-carousel-arrow" type="button" data-bs-target="#carouselRata" data-bs-slide="next">
                  <span class="carousel-control-next-icon small" aria-hidden="true"></span>
                </button>
              </div>
              <div class="w-100 px-5 text-start">
                <div class="row mb-2">
                  <div class="col-6"><p class="mb-1"><strong>Median Luas Bangunan:</strong> 126 m²</p></div>
                  <div class="col-6 ps-5"><p class="mb-1"><strong>Median Luas Tanah:</strong> 117 m²</p></div>
                </div>
                <div class="row mt-2">
                  <div class="col-12">
                    <p class="mb-1"><strong>Fasilitas :</strong></p>
                    <ul class="mb-0 ps-3" style="columns: 2; list-style-type: disc;">
                      <li>Keamanan 24 Jam</li>
                      <li>Taman</li>
                      <li>Jogging Track</li>
                      <li>AC</li>
                      <li>Kolam Renang</li>
                      <li>Jalur Telepon</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Daerah Termahal -->
        <div class="col-md-6 mb-4">
          <div class="card h-100 shadow">
            <div class="bg-light p-3 border-bottom text-center">
              <div class="d-flex align-items-center justify-content-center">
                <i class="fas fa-city me-2" style="font-size: 25px; color: #6E9489;"></i>
                <h5 class="text-uppercase fw-bold ml-3 mb-0">Daerah Termahal</h5>
              </div>
              <h6 class="mb-0">BSD Anggrek Loka</h6>
              <small class="text-muted">Rata-Rata Tertinggi : Rp8 M</small>
            </div>
            <div class="card-body d-flex flex-column align-items-center text-center">
              <div id="carouselTermahal" class="carousel slide position-relative w-100 mb-3" data-bs-ride="false">
                <div class="carousel-inner rounded-3">
                  <div class="carousel-item active"><img src="/assets/img/bsd1.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/bsd3.jpg" class="carousel-image d-block mx-auto"></div>
                  <div class="carousel-item"><img src="/assets/img/bsd2.jpg" class="carousel-image d-block mx-auto"></div>
                </div>
                <button class="carousel-control-prev custom-carousel-arrow" type="button" data-bs-target="#carouselTermahal" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon small" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next custom-carousel-arrow" type="button" data-bs-target="#carouselTermahal" data-bs-slide="next">
                  <span class="carousel-control-next-icon small" aria-hidden="true"></span>
                </button>
              </div>
              <div class="w-100 px-5 text-start">
                <div class="row mb-2">
                  <div class="col-6"><p class="mb-1"><strong>Tipe:</strong> Rumah</p></div>
                  <div class="col-6 ps-5"><p class="mb-1"><strong>Lantai:</strong> 3</p></div>
                </div>
                <div class="row">
                  <div class="col-6"><p class="mb-1"><strong>Luas Bangunan:</strong> 776 m²</p></div>
                  <div class="col-6 ps-5"><p class="mb-1"><strong>Luas Tanah:</strong> 310 m²</p></div>
                </div>
                <div class="row mt-2">
                  <div class="col-12">
                    <p class="mb-1"><strong>Fasilitas:</strong></p>
                    <ul class="mb-0 ps-3" style="columns: 3; list-style-type: disc;">
                      <li>AC</li>
                      <li>Cuci Tangan</li>
                      <li>Gerbang Utama</li>
                      <li>Jalur Telepon</li>
                      <li>Jogging Track</li>
                      <li>Keamanan 24 Jam</li>
                      <li>Kitchen Set</li>
                      <li>Taman</li>
                      <li>Tempat Jemuran</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Grafik Komparasi -->
      <div class="card mb-4 shadow-sm border-0 rounded-3">
        <div class="card-body">
          <div class="row">
            <div class="col-md-6 mb-4">
              <div class="card h-100 border-0 shadow-sm text-center">
                <div class="card-body bg-light d-flex flex-column align-items-center">
                  <img src="/assets/img/luas_tanah_vs_harga.jpg" alt="Luas Tanah vs Harga" class="img-fluid rounded mb-2 img-hover-zoom" style="max-height: 300px; object-fit: contain;" />
                  <p class="fw-semibold mb-0">Luas Tanah vs Harga</p>
                </div>
              </div>
            </div>
            <div class="col-md-6 mb-4">
              <div class="card h-100 border-0 shadow-sm text-center">
                <div class="card-body bg-light d-flex flex-column align-items-center">
                  <img src="/assets/img/luas_bangunan_vs_harga.jpg" alt="Luas Bangunan vs Harga" class="img-fluid rounded mb-2 img-hover-zoom" style="max-height: 300px; object-fit: contain;" />
                  <p class="fw-semibold mb-0">Luas Bangunan vs Harga</p>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="card border-0 shadow-sm text-center">
                <div class="card-body bg-light d-flex flex-column align-items-center">
                  <img src="/assets/img/daerah_tertinggi_terendah.jpg" alt="Harga Rata-rata per Daerah" class="img-fluid rounded mb-2 img-hover-zoom" style="max-height: 350px; object-fit: contain;" />
                  <p class="fw-semibold mb-0">Harga Rata-rata per Daerah</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- CTA -->
      <div class="text-center my-5">
        <h4 class="fw-bold mb-3">Mulai Prediksi Sekarang?</h4>
        <p class="mb-4 text-muted">Login terlebih dahulu untuk menggunakan fitur prediksi harga rumah.</p>
        <router-link to="/login">
          <button class="btn btn-primary px-4 py-2">Login</button>
        </router-link>
      </div>

    </div>
  </div>
</template>


<style scoped>
.home-header {
  margin-bottom: 20px;
}
.home-logo {
  height: 60px;
  width: auto;
  margin-bottom: 8px;
}
.content {
  margin: 0;
  padding: 0;
}
.background-page {
  background: linear-gradient(to bottom right, #4d8a3b5a, #558b446f, #f5f7fa); /* gradasi soft */
  min-height: 100vh;
  padding-top: 0;
  padding-bottom: 30px;
}

.card {
  background-color: white;
  border-radius: 12px;
}

.carousel-image {
  max-height: 250px;
  object-fit: cover;
  border-radius: 10px;
}


.no-uppercase {
  text-transform: none !important;
}

.custom-carousel-arrow {
  width: 30px;
  height: 30px;
  top: 50%;
  transform: translateY(-50%);
}

.custom-carousel-arrow .carousel-control-prev-icon,
.custom-carousel-arrow .carousel-control-next-icon {
  width: 100%;
  height: 100%;
  background-size: 100% 100%;
  background-color: transparent;
  filter: invert(0.6);
}

.carousel-image {
  width: 250px;
  height: 250px;
  object-fit: contain;
}

.card-stats {
  color: white;
  border-radius: 12px;
  transition: all 0.3s ease;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.card-stats:hover {
  transform: translateY(-5px);
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
  opacity: 0.95;
}


.icon-small i {
  font-size: 1.6rem;
}

.card-body {
  padding: 0.75rem 1rem !important;
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.card-content p {
  margin-bottom: 0.25rem;
  font-size: 0.8rem;
  color: rgba(255, 255, 255, 0.85);
}

.card-content h6 {
  margin: 0;
  font-size: 1rem;
  font-weight: 600;
}

.img-hover-zoom {
  transition: transform 0.3s ease;
}

.img-hover-zoom:hover {
  transform: scale(1.05);
}
</style>
