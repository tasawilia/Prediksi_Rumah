<!-- eslint-disable vue/multi-word-component-names -->

<template>
  <div class="content">
    <h4 class="text-center mb-4">Riwayat Prediksi Harga Rumah</h4>
    <div class="card shadow-sm rounded-4">
      <div class="card-body table-responsive">
        <button @click="exportToPDF" class="btn custom-export-button mb-3">
          Export Riwayat ke PDF
        </button>

        <table ref="tabelRiwayat" class="table table-bordered table-hover text-center align-middle">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Daerah</th>
              <th>Luas Tanah (m²)</th>
              <th>Luas Bangunan (m²)</th>
              <th>Fasilitas</th>
              <th>Harga Prediksi</th>
              <th>Tanggal</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in riwayat" :key="item.id">
              <td>{{ index + 1 }}</td>
              <td>{{ item.daerah }}</td>
              <td>{{ item.luas_tanah }}</td>
              <td>{{ item.luas_bangunan }}</td>
              <td>
                <ul style="padding-left: 18px;">
                  <li v-for="(fasilitas, i) in fasilitasAktif(item)" :key="i">{{ fasilitas }}</li>
                </ul>
              </td>
              <td>
                Rp {{ Number(item.hasil_prediksi || 0).toLocaleString('id-ID') }}
              </td>
              <td>{{ formatDate(item.created_at) }}</td>
              <td>
                <button class="custom-hapus-button no-export" @click="hapusRiwayat(item.id)">Hapus</button>
              </td>
            </tr>
          </tbody>
          <tr v-if="riwayat.length === 0">
            <td colspan="8" class="text-center">Belum ada riwayat prediksi ditemukan.</td>
          </tr>

        </table>
      </div>

      <!-- TAMPILAN UNTUK PDF SAJA -->
      <div class="pdf-only" v-show="false">
        <div class="pdf-wrapper">
          <div class="pdf-header-custom">Laporan Riwayat Prediksi Harga Rumah</div>
          <table class="prediction-history-table">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama Daerah</th>
                <th>Luas Tanah (m²)</th>
                <th>Luas Bangunan (m²)</th>
                <th>Fasilitas</th>
                <th>Harga Prediksi</th>
                <th>Tanggal</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in riwayat" :key="'pdf-' + item.id">
                <td>{{ index + 1 }}</td>
                <td>{{ item.daerah }}</td>
                <td>{{ item.luas_tanah }}</td>
                <td>{{ item.luas_bangunan }}</td>
                <td>
                  <ul class="facility-list">
                    <li v-for="(fasilitas, i) in fasilitasAktif(item)" :key="i">{{ fasilitas }}</li>
                  </ul>
                </td>
                <td>
                  Rp {{ Number(item.hasil_prediksi || 0).toLocaleString('id-ID') }}
                </td>
                <td>{{ formatDate(item.created_at) }}</td>
              </tr>
            </tbody>
          </table>
          <div class="pdf-footer">
            Dicetak pada: {{ new Date().toLocaleDateString('id-ID') }}
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<script>

import Swal from 'sweetalert2'
import html2pdf from 'html2pdf.js'
export default {
  data() {
    return {
      riwayat: []
    }
  },
  methods: {
    exportToPDF() {
      const pdfSection = this.$el.querySelector('.pdf-only');
      pdfSection.style.display = 'block'; // sementara ditampilkan agar bisa dirender

      const opt = {
        margin: 0.3,
        filename: 'riwayat-prediksi-rumah.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'A4', orientation: 'portrait' }
      };

      html2pdf().set(opt).from(pdfSection).save().then(() => {
        pdfSection.style.display = 'none'; // sembunyikan lagi setelah ekspor
      });
    },

    formatDate(dateString) {
      if (!dateString) return 'Tanggal tidak tersedia';

      const date = new Date(dateString);
      if (isNaN(date.getTime())) return 'Format tanggal tidak valid';

      const options = {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      };

      return date.toLocaleString('id-ID', options).replace(',', '');
    },
    fasilitasAktif(item) {
      return Object.entries(item)
        .filter(([key, val]) =>
          ![
            'id', 'user_id', 'daerah', 'luas_tanah', 'luas_bangunan',
            'hasil_prediksi', 'created_at'
          ].includes(key) && val === 1
        )
        .map(([key]) => key.replace(/_/g, ' '));
    },
    async hapusRiwayat(id) {
      const result = await Swal.fire({
        title: 'Hapus Riwayat?',
        text: 'Apakah kamu yakin ingin menghapus riwayat ini?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal',
        customClass: {
          popup: 'custom-swal-popup',
          title: 'custom-swal-title',
          htmlContainer: 'custom-swal-text',
          confirmButton: 'custom-confirm-button',
          cancelButton: 'custom-cancel-button'
        }
      });


      if (result.isConfirmed) {
        try {
          const response = await fetch(`http://localhost:5000/riwayat/${id}`, {
            method: "DELETE",
          });

          if (response.ok) {
            this.riwayat = this.riwayat.filter(item => item.id !== id);
            Swal.fire({
              title: 'Terhapus!',
              text: 'Riwayat berhasil dihapus.',
              icon: 'success',
              timer: 1500,
              showConfirmButton: false,
              customClass: {
                popup: 'custom-swal-popup',
                title: 'custom-swal-title',
                htmlContainer: 'custom-swal-text',
                icon: 'custom-success-icon'
              }
            });
          } else {
            const errorData = await response.json();
            Swal.fire({
              title: 'Gagal!',
              text: errorData.message || 'Gagal menghapus riwayat.',
              icon: 'error',
              customClass: {
                popup: 'custom-swal-popup',
                title: 'custom-swal-title',
                htmlContainer: 'custom-swal-text',
                confirmButton: 'custom-error-button'
              }
            });
          }
        } catch (err) {
          console.error("Error saat menghapus riwayat:", err);
          Swal.fire({
            title: 'Error!',
            text: 'Terjadi kesalahan saat menghapus.',
            icon: 'error',
            customClass: {
              popup: 'custom-swal-popup',
              title: 'custom-swal-title',
              htmlContainer: 'custom-swal-text',
              confirmButton: 'custom-error-button'
            }
          });
        }
      }
    }

  },
  async mounted() {
    try {
      const storedUser = localStorage.getItem('user');

      if (!storedUser) {
        console.warn('User belum login atau localStorage kosong.');
        this.$router.push('/login');
        return;
      }

      const user = JSON.parse(storedUser);
      const user_id = user?.id;

      if (!user_id) {
        console.warn('User ID tidak ditemukan.');
        this.$router.push('/login');
        return;
      }

      const response = await fetch(`http://localhost:5000/riwayat/${user_id}`);
      const data = await response.json();

      if (Array.isArray(data)) {
        this.riwayat = data;
      } else {
        console.warn("Format data dari API tidak sesuai:", data);
        this.riwayat = [];
      }
    } catch (error) {
      console.error('Gagal mengambil riwayat:', error);
    }
  }
}
</script>

<style>
.swal2-confirm.custom-confirm-button,
.swal2-styled.swal2-confirm.custom-confirm-button {
  background-color: #ec5545 !important;
  color: #fff !important;
  border: none !important;
  border-radius: 4px !important;
  font-size: 14px !important;
  padding: 6px 18px !important;
  box-shadow: none !important;
  margin-right: 8px;
}
.swal2-confirm.custom-confirm-button:hover,
.swal2-styled.swal2-confirm.custom-confirm-button:hover,
.swal2-confirm.custom-confirm-button:focus,
.swal2-styled.swal2-confirm.custom-confirm-button:focus {
  background-color: #d75445 !important;
  color: #fff !important;
}
/* PDF Judul */
.pdf-header {
  font-size: 24px;
  font-weight: bold;
  color: #333;
  margin-bottom: 30px;
}

/* Tabel Riwayat */
.prediction-history-table {
  width: 100%;
  border-collapse: collapse;
  font-family: Arial, sans-serif;
  color: #333;
}

.prediction-history-table th,
.prediction-history-table td {
  padding: 10px 15px;
  border: 1px solid #ddd;
  vertical-align: top;
}

.prediction-history-table thead {
  background-color: #6E9489;
  color: white;
  font-weight: bold;
}

.prediction-history-table tbody tr:nth-child(even) {
  background-color: #f8f8f8;
}

/* Daftar Fasilitas */
.facility-list {
  list-style-type: disc;
  padding-left: 20px;
  margin: 0;
  text-align: left;
}

.facility-list li {
  margin-bottom: 3px;
}

/* Tombol Hapus */
.custom-hapus-button {
  background-color: #e74c3c !important;
  color: white;
  font-size: 12px;
  padding: 5px 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.custom-hapus-button:hover {
  background-color: #c0392b !important;
}

.custom-hapus-button:focus {
  outline: none !important;
  box-shadow: none !important;
}

/* Tombol Export */
.custom-export-button {
  background-color: #6E9489 !important;
  color: white !important;
  border: none !important;
}

.custom-export-button:hover {
  background-color: #6E9489 !important;
  color: white !important;
}

/* Hide kolom saat cetak */
@media print {
  .no-export {
    display: none !important;
  }

  .pdf-only {
    display: block !important;
  }
}

/* Desain PDF */
.pdf-wrapper {
  padding: 20px;
  border: 2px solid #6E9489;
  border-radius: 10px;
  background-color: #fdfdfd;
  font-family: Arial, sans-serif;
}

.pdf-header-custom {
  text-align: center;
  font-size: 26px;
  font-weight: bold;
  margin-bottom: 20px;
  color: #2c3e50;
  border-bottom: 2px solid #6E9489;
  padding-bottom: 10px;
}

.prediction-history-table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 15px;
  font-size: 14px;
}

.prediction-history-table th,
.prediction-history-table td {
  padding: 8px 10px;
  border: 1px solid #ccc;
  vertical-align: top;
  text-align: left;
}

.prediction-history-table thead {
  background-color: #6E9489;
  color: white;
}

.facility-list {
  list-style-type: disc;
  padding-left: 18px;
  margin: 0;
}

.facility-list li {
  margin-bottom: 3px;
}

.pdf-footer {
  text-align: right;
  font-size: 12px;
  color: #555;
  margin-top: 30px;
}


/* Judul Halaman */
h4 {
  font-weight: 600;
}
</style>
