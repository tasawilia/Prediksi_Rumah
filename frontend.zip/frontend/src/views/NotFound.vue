<!-- eslint-disable vue/multi-word-component-names  -->

<template>
    <div class="not-found-container">
      <h1>404</h1>
      <p>Oops! Halaman yang kamu cari tidak ditemukan.</p>
      <router-link to="/" class="back-home">Kembali ke Login</router-link>
    </div>
  </template>
  
  <style scoped>
  .not-found-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    text-align: center;
    padding: 20px;
    background-color: #f8f9f8;
    color: #2e423d;
  }
  
  h1 {
    font-size: 8rem;
    margin-bottom: 0.5rem;
    color: #6E9489;
  }
  
  p {
    font-size: 1.2rem;
    margin-bottom: 20px;
  }
  
  .back-home {
    padding: 10px 20px;
    background-color: #6E9489;
    color: white;
    text-decoration: none;
    font-weight: bold;
    border-radius: 6px;
    transition: background-color 0.3s;
  }
  
  .back-home:hover {
    background-color: #557a6f;
  }
  </style>
  