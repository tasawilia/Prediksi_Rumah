<!-- eslint-disable vue/multi-word-component-names -->

<template>
    <div class="content">
        <div class="row">
            <div class="col-md-4">
                <div class="card card-user">
                    <div class="card-header">
                        <h5 class="card-title">Edit Profil</h5>
                    </div>
                    <div class="card-body">
                        <form @submit.prevent="simpanPerubahan">
                            <div class="shadow-sm p-1 bg-body-tertiary rounded">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Nama</label>
                                    <input type="text" class="form-control" id="name" v-model="nama"
                                        placeholder="Nama Lengkap" />
                                </div>

                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" v-model="email"
                                        placeholder="Email" />
                                </div>

                                <div class="mb-3">
                                    <label for="password" class="form-label">Password Baru</label>
                                    <input type="password" class="form-control" id="password" v-model="password"
                                        placeholder="Biarkan kosong jika tidak diganti" />
                                </div>
                            </div>

                            <div class="card-footer">
                                <div class="button-container text-center">
                                    <button type="submit" class="btn btn-custom">
                                        Simpan Perubahan
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Swal from 'sweetalert2'
import axios from 'axios'

export default {
    data() {
        return {
            nama: '',
            email: '',
            password: '',
            api: 'http://localhost:5000/userProfilUpdate',
        }
    },
    created() {
        const user = JSON.parse(localStorage.getItem('user'))
        if (user) {
            this.nama = user.nama
            this.email = user.email
        }
    },
    methods: {
        async simpanPerubahan() {
            const user = JSON.parse(localStorage.getItem('user'))

            if (!user || !user.id) {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: 'User tidak ditemukan.',
                    confirmButtonColor: '#6E9489'
                })
                return
            }

            const requestData = {
                id: user.id,
                nama: this.nama,
                email: this.email,
                password: this.password || '',
            }

            try {
                const response = await axios.put(this.api, requestData)

                localStorage.setItem('user', JSON.stringify(response.data.user))

                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: 'Data berhasil diperbarui.',
                    confirmButtonColor: '#6E9489',
                    background: '#F6F6F6',
                    color: '#333',
                    customClass: {
                        popup: 'small-swal'
                    }
                }).then(() => {
                    this.$router.push('/profil')
                })


            } catch (err) {
                console.error('Error saat update profil:', err);

                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: err.response?.data?.error || 'Terjadi kesalahan saat update.',
                    confirmButtonColor: '#6E9489'
                })
            }
        }
    }
}

</script>

<style>
.small-swal {
    width: 300px !important;
    height: auto;
    padding: 1.2rem !important;
    font-size: 12px;
}
</style>
<style scoped>
.btn-custom {
    background-color: #6E9489;
    color: white;
    border: none;
}

.btn-custom:hover {
    background-color: #5c7c74;
}

.card-header {
    padding-bottom: 0;
}

.card-body {
    padding-top: 0.25rem;
}

h5 {
    font-weight: 600;
}
</style>