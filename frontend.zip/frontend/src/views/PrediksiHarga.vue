<!-- eslint-disable vue/multi-word-component-names -->

<template>
  <div class="content">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="card card-user shadow-sm rounded-4">
          <div class="card-body">
            <h4 class="card-title mb-4 text-center">Prediksi Harga Rumah</h4>
            <form @submit.prevent="submitForm">
              <!-- Nama Daerah -->
              <div class="mb-4">
                <label class="form-label">Nama Daerah</label>
                <select class="form-select w-100" v-model="form.daerah">
                  <option disabled value="">Pilih Daerah</option>
                  <option v-for="d in daftarDaerah" :key="d" :value="d">{{ d }}</option>
                </select>
              </div>

              <!-- Luas Tanah -->
              <div class="mb-4">
                <label class="form-label">Luas Tanah (m²)</label>
                <input type="number" v-model="form.luas_tanah" class="form-control" />
              </div>

              <!-- Luas Bangunan -->
              <div class="mb-4">
                <label class="form-label">Luas Bangunan (m²)</label>
                <input type="number" v-model="form.luas_bangunan" class="form-control" />
              </div>

              <!-- Fasilitas -->
              <div class="mb-4">
                <label class="form-label">Fasilitas</label>
                <multiselect v-model="form.fasilitas" :options="fasilitasList" :multiple="true" :close-on-select="false"
                  placeholder="Pilih Fasilitas" class="w-100" />
              </div>

              <!-- Button -->
              <div class="text-center">
                <button type="submit" class="btn btn-custom">Prediksi Harga</button>
              </div>
            </form>
            <div v-if="hasilPrediksi !== null" class="alert alert-success mt-4 text-center">
              Hasil Prediksi Harga: <strong>Rp {{ hasilPrediksi.toLocaleString('id-ID') }}</strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Multiselect from 'vue-multiselect'
import 'vue-multiselect/dist/vue-multiselect.min.css'
import Swal from 'sweetalert2'

export default {
  components: { Multiselect },
  data() {
    return {
      form: {
        daerah: '',
        luas_tanah: '',
        luas_bangunan: '',
        fasilitas: []
      },
      daftarDaerah: [],
      fasilitasList: [
        "Ac", "Akses Parkir", "Carport", "Cctv", "Cuci Tangan", "Gerbang Utama",
        "Jalur Telepon", "Jogging Track", "Keamanan 24 Jam", "Kitchen Set", "Kolam Ikan",
        "Kolam Renang", "Kulkas", "Lapangan Basket", "Lapangan Bola", "Lapangan Bulu Tangkis",
        "Lapangan Tenis", "Lapangan Voli", "Masjid", "Mesin Cuci", "Pemanas Air",
        "Playground", "Taman", "Tempat Gym", "Tempat Jemuran", "Tempat Laundry"
      ],
      hasilPrediksi: null
    }
  },
  mounted() {
    // Panggil fetchDaerah saat komponen dimuat
    this.fetchDaerah()
  },
  methods: {
    async fetchDaerah() {
      try {
        const response = await fetch("http://localhost:5000/daerah")
        const data = await response.json()
        this.daftarDaerah = data
      } catch (err) {
        Swal.fire("Gagal!", "Gagal mengambil daftar daerah dari server.", "error")
      }
    },
    async submitForm() {
      // Validasi input sebelum submit
      if (!this.form.daerah || !this.form.luas_tanah || !this.form.luas_bangunan) {
        Swal.fire('Gagal!', 'Semua field wajib diisi.', 'error')
        return
      }
      // Pastikan tipe data number
      const payload = {
        ...this.form,
        luas_tanah: Number(this.form.luas_tanah),
        luas_bangunan: Number(this.form.luas_bangunan),
        fasilitas: this.form.fasilitas
      }
      try {
        const response = await fetch("http://localhost:5000/prediksi", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        })
        const data = await response.json()

        if (response.ok) {
          this.hasilPrediksi = data.prediksi_harga

          // Tampilkan hasil prediksi dengan SweetAlert kecil dan tombol simpan
          const result = await Swal.fire({
            title: 'Hasil Prediksi',
            text: `Rp ${data.prediksi_harga.toLocaleString('id-ID')}`,
            icon: 'success',
            showCancelButton: true,
            confirmButtonText: 'Simpan',
            cancelButtonText: 'Tidak',
            heightAuto: false,
            customClass: {
              popup: 'swal2-small-popup',
              confirmButton: 'swal2-custom-confirm',
              cancelButton: 'swal2-custom-cancel'
            },
            buttonsStyling: false
          })

          // Pastikan ada user yang terdaftar
          const user = JSON.parse(localStorage.getItem('user'))
          if (!user || !user.id) {
            return Swal.fire('Gagal!', 'User tidak ditemukan atau tidak terdaftar.', 'error')
          }
          const user_id = user.id

          if (result.isConfirmed) {
            // Panggil endpoint untuk menyimpan (jika tersedia)
            const simpanResponse = await fetch("http://localhost:5000/simpan", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                ...payload,
                prediksi_harga: this.hasilPrediksi,
                user_id: user_id
              })
            })

            const simpanData = await simpanResponse.json()

            if (simpanResponse.ok) {
              Swal.fire({
                title: 'Tersimpan!',
                text: 'Hasil prediksi berhasil disimpan.',
                icon: 'success',
                timer: 3000,
                showConfirmButton: false,
                customClass: {
                  popup: 'custom-swal-popup',
                  title: 'custom-swal-title',
                  htmlContainer: 'custom-swal-text',
                  icon: 'custom-success-icon'
                }
              });
              setTimeout(() => {
                this.$router.push('/riwayatprediksi');
              }, 1500);
            } else {
              Swal.fire({
                title: 'Gagal!',
                text: simpanData.error || 'Terjadi kesalahan saat menyimpan data.',
                width: '280px',
                icon: 'error',
                customClass: {
                  popup: 'custom-swal-popup',
                  title: 'custom-swal-title',
                  htmlContainer: 'custom-swal-text',
                  confirmButton: 'custom-error-button'
                }
              });
            }
          }
        } else {
          // Tampilkan error detail dari backend jika ada
          console.error('Backend error:', data)
          Swal.fire({
            icon: 'error',
            title: 'Gagal Memprediksi',
            text: data.error || 'Gagal melakukan prediksi. Pastikan inputan data daerah, luas tanah dan bangunan terisi',
            width: '280px',
            customClass: {
              popup: 'custom-swal-popup',
              title: 'custom-swal-title',
              htmlContainer: 'custom-swal-text',
              confirmButton: 'custom-error-button'
            }
          })
        }
      } catch (err) {
        Swal.fire('Error!', 'Terjadi kesalahan saat menghubungi server.', 'error')
        console.error('Error saat prediksi:', err)
      }
    }
  }
}
</script>


<style>
.custom-swal-popup {
  font-size: 12px !important;
  padding: 10px !important;
  max-width: 280px !important;
}

.custom-swal-title {
  font-size: 14px !important;
  margin-bottom: 5px !important;
}

.custom-swal-text {
  font-size: 14px !important;
}

.custom-success-icon .swal2-success-line-tip,
.custom-success-icon .swal2-success-line-long,
.custom-success-icon .swal2-success-ring {
  border-color: #6E9489 !important;
}

.custom-success-icon .swal2-success-ring {
  border-width: 4px !important;
}

.custom-error-button {
  background-color: #6E9489 !important;
  color: #fff !important;
  font-size: 12px !important;
  padding: 5px 15px !important;
  border-radius: 4px !important;
  box-shadow: none !important;
  border: none !important;
}

.swal2-small-popup {
  max-width: 300px;
  font-size: 12px;
}

.swal2-custom-confirm {
  background-color: #6E9489;
  color: white;
  border: none !important;
  padding: 6px 20px;
  font-size: 13px;
  cursor: pointer;
}

.swal2-custom-cancel {
  background-color: #e74c3c !important;
  color: white;
  border: none !important;
  padding: 6px 20px;
  border-radius: 4px;
  font-size: 13px;
  margin-left: 8px;
  cursor: pointer;
}

.swal2-custom-confirm:focus,
.swal2-custom-cancel:focus {
  outline: none !important;
  box-shadow: none !important;
}

.form-label {
  display: block;
  font-weight: 500;
  margin-bottom: 0.5rem;
}

.form-select option:hover {
  background-color: #6E9489 !important;
  color: #fff !important;
}

.form-select,
.multiselect {
  width: 100%;
  min-height: 38px;
  border-radius: 0.375rem;
  font-size: 1rem;
  color: #212529;
  border: 1px solid #ced4da;
  background-color: #fff;
  padding: 0.375rem 0.75rem;
  box-sizing: border-box;
}


/* Multiselect bagian input dan placeholder */
.multiselect__tags {
  background-color: #fff;
  border: none;
  min-height: auto;
  padding: 0;
  color: #212529;
  box-shadow: none;
  font-size: 1rem;
}

.multiselect:focus,
.multiselect__tags:focus {
  outline: none;
  box-shadow: none;
}

.btn-custom {
  background-color: #6E9489;
  color: white;
  border: none;
}

.btn-custom:hover {
  background-color: #5c7c74;
}

h4 {
  font-weight: 600;
}
</style>
