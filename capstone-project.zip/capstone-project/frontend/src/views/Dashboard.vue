<!-- eslint-disable vue/multi-word-component-names -->

<template>
  <div class="content">
    <div class="container">
      <div class="row gx-0 ">
        <div class="col-md-6 mb-4">
          <div class="card h-100 shadow">
            <!-- Header Card -->
            <div class="bg-light p-3 border-bottom text-center">
              <div class="d-flex align-items-center justify-content-center">
                <i class="fas fa-coins me-2" style="font-size: 25px; color: #6E9489;"></i>
                <h5 class="text-uppercase fw-bold ml-3 mb-0" style="font-weight: 700;">Harga Minimum</h5>
              </div>
              <h6 class="mb-0 no-uppercase">Rp125 Juta</h6>
              <small class="text-muted mt-0">Daerah: Sepatan</small>
            </div>
            <!-- Body Card -->
            <div class="card-body d-flex flex-column align-items-center text-center">
              <!-- Carousel -->
              <div id="carouselMinimum" class="carousel slide position-relative w-100 mb-3" data-bs-ride="false">
                <div class="carousel-inner rounded-3">
                  <div class="carousel-item active">
                    <img src="/assets/img/terendah1.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/terendah2.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/terendah3.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/terendah4.jpg" class="carousel-image d-block mx-auto">
                  </div>
                </div>
                <button class="carousel-control-prev custom-carousel-arrow" type="button"
                  data-bs-target="#carouselMinimum" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon small" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next custom-carousel-arrow" type="button"
                  data-bs-target="#carouselMinimum" data-bs-slide="next">
                  <span class="carousel-control-next-icon small" aria-hidden="true"></span>
                </button>
              </div>
              <!-- Detail -->
              <div class="w-100 px-5 text-start">
                <div class="row mb-2">
                  <div class="col-6">
                    <p class="mb-1 text-justify"><strong>Tipe:</strong> Rumah</p>
                  </div>
                  <div class="col-6 ps-5">
                    <p class="mb-1 text-justify"><strong>Lantai:</strong> 1</p>
                  </div>
                </div>
                <div class="row">
                  <div class="col-6">
                    <p class="mb-1 text-justify"><strong>Luas Bangunan:</strong> 36 m²</p>
                  </div>
                  <div class="col-6 ps-5">
                    <p class="mb-1 text-justify"><strong>Luas Tanah:</strong> 60 m²</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6 mb-4">
          <div class="card h-100 shadow">
            <!-- Header Card -->
            <div class="bg-light p-3 border-bottom text-center">
              <div class="d-flex align-items-center justify-content-center">
                <i class="fas fa-coins me-2" style="font-size: 25px; color: #6E9489;"></i>
                <h5 class="text-uppercase fw-bold ml-3 mb-0" style="font-weight: 700;">Harga Maksimum</h5>
              </div>
              <h6 class="mb-0 no-uppercase">Rp8,25 M</h6>
              <small class="text-muted mt-0">Daerah: BSD City</small>
            </div>
            <!-- Body Card -->
            <div class="card-body d-flex flex-column align-items-center text-center">
              <!-- Carousel -->
              <div id="carouselMaximum" class="carousel slide position-relative w-100 mb-3" data-bs-ride="false">
                <div class="carousel-inner rounded-3">
                  <div class="carousel-item active">
                    <img src="/assets/img/tertinggi4.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/tertinggi1.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/tertinggi2.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/tertinggi3.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/tertinggi5.jpg" class="carousel-image d-block mx-auto">
                  </div>
                </div>
                <button class="carousel-control-prev custom-carousel-arrow" type="button"
                  data-bs-target="#carouselMaximum" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon small" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next custom-carousel-arrow" type="button"
                  data-bs-target="#carouselMaximum" data-bs-slide="next">
                  <span class="carousel-control-next-icon small" aria-hidden="true"></span>
                </button>
              </div>
              <!-- Detail -->
              <div class="w-100 px-5 text-start">
                <div class="row mb-2">
                  <div class="col-6">
                    <p class="mb-1 text-justify"><strong>Tipe:</strong> Rumah</p>
                  </div>
                  <div class="col-6 ps-5">
                    <p class="mb-1 text-justify"><strong>Lantai:</strong> 3</p>
                  </div>
                </div>
                <div class="row">
                  <div class="col-6">
                    <p class="mb-1 text-justify"><strong>Luas Bangunan:</strong> 750 m²</p>
                  </div>
                  <div class="col-6 ps-5">
                    <p class="mb-1 text-justify"><strong>Luas Tanah:</strong> 450 m²</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row gx-0">
        <div class="col-md-6 mb-4">
          <div class="card h-100 shadow">
            <!-- Header Card -->
            <div class="bg-light p-3 border-bottom text-center ">
              <!-- Icon dan Judul -->
              <div class="d-flex align-items-center justify-content-center">
                <i class="fas fa-coins me-2" style="font-size: 25px; color: #6E9489;"></i>
                <h5 class="text-uppercase fw-bold ml-3 mb-0" style="font-weight: 700;">Harga Rata-Rata</h5>
              </div>
              
              <!-- <div class="dropdown">
                <button ref="dropdownBtn" class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button"
                  id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                  Daerah
                </button>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownMenuButton1">
                  <li><button class="dropdown-item" @click="updateDaerah('gading')">Gading Serpong</button></li>
                  <li><button class="dropdown-item" @click="updateDaerah('bsdcity')">BSD City</button></li>
                  <li><button class="dropdown-item" @click="updateDaerah('sutera')">Alam Sutera</button></li>
                  <li><button class="dropdown-item" @click="updateDaerah('pagedangan')">Pagedangan</button></li>
                  <li><button class="dropdown-item" @click="updateDaerah('tigaraksa')">Tigaraksa</button></li>
                  <li>
                    <hr class="dropdown-divider" />
                  </li>
                  <li><button class="dropdown-item" @click="updateDaerah(null)">Reset</button></li>
                </ul>
              </div> -->

              <!-- Harga & Info Daerah -->
              <h6 class="mb-0 no-uppercase">Rp2,52 M</h6>
              <small class="text-muted mt-0">Seluruh Daerah Tangerang</small>

            </div>

            <!-- Body Card (carousel dan lainnya bisa masuk di sini) -->
            <div class="card-body d-flex flex-column align-items-center text-center">
              <div id="carouselRata" class="carousel slide position-relative w-100 mb-3" data-bs-ride="false">
                <div class="carousel-inner rounded-3">
                  <div class="carousel-item active">
                    <img src="/assets/img/gaser1.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/gaser2.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/gaser3.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/gaser4.jpg" class="carousel-image d-block mx-auto">
                  </div>
                </div>
                <button class="carousel-control-prev custom-carousel-arrow" type="button" data-bs-target="#carouselRata"
                  data-bs-slide="prev">
                  <span class="carousel-control-prev-icon small" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next custom-carousel-arrow" type="button" data-bs-target="#carouselRata"
                  data-bs-slide="next">
                  <span class="carousel-control-next-icon small" aria-hidden="true"></span>
                </button>
              </div>
              <!-- Detail -->


            </div>
          </div>
        </div>

        <div class="col-md-6 mb-4">
          <div class="card h-100 shadow">
            <!-- Header Card -->
            <div class="bg-light p-3 border-bottom text-center">
              <div class="d-flex align-items-center justify-content-center">
                <i class="fas fa-city me-2" style="font-size: 25px; color: #6E9489;"></i>
                <h5 class="text-uppercase fw-bold ml-3 mb-0" style="font-weight: 700;">Daerah Termahal</h5>
              </div>
              <h6 class="mb-0 no-uppercase">BSD Anggrek Loka</h6>
              <small class="text-muted mt-0">Rata-Rata Tertinggi : Rp8 M</small>
            </div>
            <!-- Body Card -->
            <div class="card-body d-flex flex-column align-items-center text-center">
              <!-- Carousel -->
              <div id="carouselTermahal" class="carousel slide position-relative w-100 mb-3" data-bs-ride="false">
                <div class="carousel-inner rounded-3">
                  <div class="carousel-item active">
                    <img src="/assets/img/bsd1.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/bsd3.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/bsd2.jpg" class="carousel-image d-block mx-auto">
                  </div>
                </div>
                <button class="carousel-control-prev custom-carousel-arrow" type="button"
                  data-bs-target="#carouselTermahal" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon small" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next custom-carousel-arrow" type="button"
                  data-bs-target="#carouselTermahal" data-bs-slide="next">
                  <span class="carousel-control-next-icon small" aria-hidden="true"></span>
                </button>
              </div>
              <!-- Detail -->
              <div class="w-100 px-5 text-start">
                <div class="row mb-2">
                  <div class="col-6">
                    <p class="mb-1 text-justify"><strong>Tipe:</strong> Rumah</p>
                  </div>
                  <div class="col-6 ps-5">
                    <p class="mb-1 text-justify"><strong>Lantai:</strong> 3</p>
                  </div>
                </div>
                <div class="row">
                  <div class="col-6">
                    <p class="mb-1 text-justify"><strong>Luas Bangunan:</strong> 776 m²</p>
                  </div>
                  <div class="col-6 ps-5">
                    <p class="mb-1 text-justify"><strong>Luas Tanah:</strong> 310 m²</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="card mb-4 shadow-sm border-0 rounded-3">
      <div class="card-body">
        <div class="row">
          <!-- Gambar 1 -->
          <div class="col-md-6 mb-4">
            <div class="card h-100 border-0 shadow-sm text-center">
              <div class="card-body bg-light d-flex flex-column align-items-center">
                <img src="/assets/img/luas_tanah_vs_harga.jpg" alt="Luas Tanah vs Harga"
                  class="img-fluid rounded mb-2 img-hover-zoom" style="max-height: 300px; object-fit: contain;" />
                <p class="fw-semibold mb-0">Luas Tanah vs Harga</p>
              </div>
            </div>
          </div>

          <!-- Gambar 2 -->
          <div class="col-md-6 mb-4">
            <div class="card h-100 border-0 shadow-sm text-center">
              <div class="card-body bg-light d-flex flex-column align-items-center">
                <img src="/assets/img/luas_bangunan_vs_harga.jpg" alt="Luas Bangunan vs Harga"
                  class="img-fluid rounded mb-2 img-hover-zoom" style="max-height: 300px; object-fit: contain;" />
                <p class="fw-semibold mb-0">Luas Bangunan vs Harga</p>
              </div>
            </div>
          </div>

          <!-- Gambar 3 -->
          <div class="col-md-12">
            <div class="card border-0 shadow-sm text-center">
              <div class="card-body bg-light d-flex flex-column align-items-center">
                <img src="/assets/img/daerah_tertinggi_terendah.jpg" alt="Daerah Harga Tertinggi & Terendah"
                  class="img-fluid rounded mb-2 img-hover-zoom" style="max-height: 350px; object-fit: contain;" />
                <p class="fw-semibold mb-0">Harga Rata-rata per Daerah</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<!-- <script>
import { Dropdown } from 'bootstrap';

export default {
  data() {
    return {
      form: {
        daerah: null
      }
    }
  },
  methods: {
    updateDaerah(daerah) {
      this.form.daerah = daerah;
      console.log("Daerah dipilih:", daerah);
    }
  },
  mounted() {
    try {
      this.dropdownInstance = new Dropdown(this.$refs.dropdownBtn); // Simpan kalau perlu
      console.log("Dropdown initialized via ref");

      this.$refs.dropdownBtn.addEventListener('click', () => {
        console.log("Dropdown clicked via ref");
      });
    } catch (err) {
      console.error("Dropdown error:", err);
    }
  }

}

</script> -->



<style scoped>
.no-uppercase {
  text-transform: none !important;
}

.custom-carousel-arrow {
  width: 30px;
  height: 30px;
  top: 50%;
  transform: translateY(-50%);
}

.custom-carousel-arrow .carousel-control-prev-icon,
.custom-carousel-arrow .carousel-control-next-icon {
  width: 100%;
  height: 100%;
  background-size: 100% 100%;
  background-color: transparent;
  filter: invert(0.6);
}

.carousel-image {
  width: 250px;
  height: 250px;
  object-fit: contain;
}

.card-stats {
  color: white;
  border-radius: 12px;
  transition: all 0.3s ease;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.card-stats:hover {
  transform: translateY(-5px);
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
  opacity: 0.95;
}


.icon-small i {
  font-size: 1.6rem;
}

.card-body {
  padding: 0.75rem 1rem !important;
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.card-content p {
  margin-bottom: 0.25rem;
  font-size: 0.8rem;
  color: rgba(255, 255, 255, 0.85);
}

.card-content h6 {
  margin: 0;
  font-size: 1rem;
  font-weight: 600;
}

.img-hover-zoom {
  transition: transform 0.3s ease;
}

.img-hover-zoom:hover {
  transform: scale(1.05);
}
</style>

<!-- <div class="col-md-6 mb-4">
          <div class="card h-100 shadow"> -->
<!-- Header Card -->
<!-- <div class="bg-light p-3 border-bottom text-center">
              <div class="d-flex align-items-center justify-content-center">
                <i class="fas fa-coins me-2" style="font-size: 25px; color: #6E9489;"></i>
                <h5 class="text-uppercase fw-bold ml-3 mb-0" style="font-weight: 700;">Harga Rata-Rata </h5>
              </div>
              <h6 class="mb-0 no-uppercase">Rp2,53 Juta</h6>
              <small class="text-muted mt-0">Daerah: Gading Serpong = 14 rumah</small>
            </div> -->
<!-- Body Card -->
<!-- <div class="card-body d-flex flex-column align-items-center text-center"> -->
<!-- Carousel -->
<!-- <div id="carouselRata" class="carousel slide position-relative w-100 mb-3" data-bs-ride="false">
                <div class="carousel-inner rounded-3">
                  <div class="carousel-item active">
                    <img src="/assets/img/gaser1.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/gaser2.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/gaser3.jpg" class="carousel-image d-block mx-auto">
                  </div>
                  <div class="carousel-item">
                    <img src="/assets/img/gaser4.jpg" class="carousel-image d-block mx-auto">
                  </div>
                </div>
                <button class="carousel-control-prev custom-carousel-arrow" type="button"
                  data-bs-target="#carouselRata" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon small" aria-hidden="true"></span>
                </button>
                <button class="carousel-control-next custom-carousel-arrow" type="button"
                  data-bs-target="#carouselRata" data-bs-slide="next">
                  <span class="carousel-control-next-icon small" aria-hidden="true"></span>
                </button>
              </div>
              <div class="w-100 px-3">
                <div class="row mb-2">
                  <div class="col-6">
                    <p class="mb-1 text-justify"><strong>Tipe:</strong> Rumah</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div> -->

        <!-- aa
         
        
        -->