<!-- eslint-disable vue/multi-word-component-names -->

<template>
  <div class="content" v-if="user">
    <div class="row">
      <div class="col-md-4">
        <div class="card card-user">
          <div class="image text-center mt-3">
            <img class="avatar border-gray" src="/assets/img/profil_hijab.jpg"
              style="width: 100px; height: 100px; object-fit: cover; border-radius: 50%;">
          </div>
          <div class="card-body">
            <div class="author text-center">
              <h5 class="title mt-5">{{ user.nama }}</h5>
            </div>

            <div class="shadow-sm p-3 bg-body-tertiary rounded">
              <div class="mb-3">
                <p class="form-control">{{ user.nama }}</p>
              </div>
              <div class="mb-3">
                <p class="form-control">{{ user.email }}</p>
              </div>
              <div class="mb-3">
                <p class="form-control">********</p>
              </div>
            </div>
          </div>
          <div class="card-footer">
            <div class="button-container text-center">
              <router-link to="/editprofil" class="btn btn-custom">
                Edit Profil
              </router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      user: null
    };
  },
  created() {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      this.user = JSON.parse(storedUser);
    } else {
      console.warn('User belum login atau localStorage kosong.');
      this.$router.push('/login');
    }
  }
};
</script>




<style scoped>
.btn-custom {
  background-color: #6E9489;
  color: white;
  border: none;
}

.btn-custom:hover {
  background-color: #5c7c74;
}
</style>