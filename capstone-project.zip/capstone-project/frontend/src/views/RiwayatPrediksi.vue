<!-- eslint-disable vue/multi-word-component-names -->

<template>
  <div class="content">
    <h4 class="text-center mb-4">Riwayat Prediksi Harga Rumah</h4>
    <div class="card shadow-sm rounded-4">
      <div class="card-body table-responsive">
        <table class="table table-bordered table-hover text-center align-middle">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Daerah</th>
              <th>Luas Tanah (m²)</th>
              <th>Luas Bangunan (m²)</th>
              <th>Fasilitas</th>
              <th>Harga Prediksi</th>
              <th>Tanggal</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item, index) in riwayat" :key="item.id">
              <td>{{ index + 1 }}</td>
              <td>{{ item.daerah }}</td>
              <td>{{ item.luas_tanah }}</td>
              <td>{{ item.luas_bangunan }}</td>
              <td>
                <ul style="padding-left: 18px;">
                  <li v-for="(fasilitas, i) in fasilitasAktif(item)" :key="i">{{ fasilitas }}</li>
                </ul>
              </td>
              <td>
                Rp {{ Number(item.hasil_prediksi || 0).toLocaleString('id-ID') }}
              </td>
              <td>{{ formatDate(item.created_at) }}</td>
              <td>
                <button class="custom-hapus-button" @click="hapusRiwayat(item.id)">Hapus</button>
              </td>
            </tr>
          </tbody>
          <tr v-if="riwayat.length === 0">
            <td colspan="8" class="text-center">Belum ada riwayat prediksi ditemukan.</td>
          </tr>

        </table>
      </div>
    </div>
  </div>
</template>

<script>

import Swal from 'sweetalert2'
export default {
  data() {
    return {
      riwayat: []
    }
  },
  methods: {
    formatDate(dateString) {
      if (!dateString) return 'Tanggal tidak tersedia';

      const date = new Date(dateString);
      if (isNaN(date.getTime())) return 'Format tanggal tidak valid';

      const options = {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      };

      return date.toLocaleString('id-ID', options).replace(',', '');
    },
    fasilitasAktif(item) {
      return Object.entries(item)
        .filter(([key, val]) =>
          ![
            'id', 'user_id', 'daerah', 'luas_tanah', 'luas_bangunan',
            'hasil_prediksi', 'created_at'
          ].includes(key) && val === 1
        )
        .map(([key]) => key.replace(/_/g, ' '));
    },
    async hapusRiwayat(id) {
      const result = await Swal.fire({
        title: 'Hapus Riwayat?',
        text: 'Apakah kamu yakin ingin menghapus riwayat ini?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal',
        customClass: {
          popup: 'custom-swal-popup',
          title: 'custom-swal-title',
          htmlContainer: 'custom-swal-text',
          confirmButton: 'custom-confirm-button',
          cancelButton: 'custom-cancel-button'
        }
      });


      if (result.isConfirmed) {
        try {
          const response = await fetch(`http://localhost:5000/riwayat/${id}`, {
            method: "DELETE",
          });

          if (response.ok) {
            this.riwayat = this.riwayat.filter(item => item.id !== id);
            Swal.fire({
              title: 'Terhapus!',
              text: 'Riwayat berhasil dihapus.',
              icon: 'success',
              timer: 1500,
              showConfirmButton: false,
              customClass: {
                popup: 'custom-swal-popup',
                title: 'custom-swal-title',
                htmlContainer: 'custom-swal-text',
                icon: 'custom-success-icon'
              }
            });
          } else {
            const errorData = await response.json();
            Swal.fire({
              title: 'Gagal!',
              text: errorData.message || 'Gagal menghapus riwayat.',
              icon: 'error',
              customClass: {
                popup: 'custom-swal-popup',
                title: 'custom-swal-title',
                htmlContainer: 'custom-swal-text',
                confirmButton: 'custom-error-button'
              }
            });
          }
        } catch (err) {
          console.error("Error saat menghapus riwayat:", err);
          Swal.fire({
            title: 'Error!',
            text: 'Terjadi kesalahan saat menghapus.',
            icon: 'error',
            customClass: {
              popup: 'custom-swal-popup',
              title: 'custom-swal-title',
              htmlContainer: 'custom-swal-text',
              confirmButton: 'custom-error-button'
            }
          });
        }
      }
    }

  },
  async mounted() {
    try {
      const storedUser = localStorage.getItem('user');

      if (!storedUser) {
        console.warn('User belum login atau localStorage kosong.');
        this.$router.push('/login');
        return;
      }

      const user = JSON.parse(storedUser);
      const user_id = user?.id;

      if (!user_id) {
        console.warn('User ID tidak ditemukan.');
        this.$router.push('/login');
        return;
      }

      const response = await fetch(`http://localhost:5000/riwayat/${user_id}`);
      const data = await response.json();

      if (Array.isArray(data)) {
        this.riwayat = data;
      } else {
        console.warn("Format data dari API tidak sesuai:", data);
        this.riwayat = [];
      }
    } catch (error) {
      console.error('Gagal mengambil riwayat:', error);
    }
  }
}
</script>

<style>
.custom-hapus-button {
  background-color: #e74c3c !important;
  /* merah */
  color: white;
  font-size: 12px;
  padding: 5px 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.custom-hapus-button:hover {
  background-color: #c0392b !important;
  /* merah lebih gelap saat hover */
}

.custom-hapus-button:focus {
  outline: none !important;
  box-shadow: none !important;
}

.custom-confirm-button:focus,
.custom-cancel-button:focus {
  outline: none !important;
  box-shadow: none !important;
}

.custom-confirm-button {
  background-color: #e74c3c !important;
  /* Merah */
  color: #fff !important;
  font-size: 12px !important;
  padding: 5px 15px !important;
  border-radius: 4px !important;
  box-shadow: none !important;
  border: none !important;
}

.custom-cancel-button {
  background-color: #6E9489 !important;
  /* Abu hijau */
  color: #fff !important;
  font-size: 12px !important;
  padding: 5px 15px !important;
  border-radius: 4px !important;
  box-shadow: none !important;
  border: none !important;
}

.custom-swal-popup {
  font-size: 12px !important;
  padding: 10px !important;
  max-width: 280px !important;
}

.custom-swal-title {
  font-size: 14px !important;
  margin-bottom: 5px !important;
}

.custom-swal-text {
  font-size: 14px !important;
}

.custom-success-icon .swal2-success-line-tip,
.custom-success-icon .swal2-success-line-long,
.custom-success-icon .swal2-success-ring {
  border-color: #6E9489 !important;
}

.custom-success-icon .swal2-success-ring {
  border-width: 4px !important;
}

.custom-error-button {
  background-color: #6E9489 !important;
  color: #fff !important;
  font-size: 12px !important;
  padding: 5px 15px !important;
  border-radius: 4px !important;
  box-shadow: none !important;
  border: none !important;
}

.table th,
.table td {
  vertical-align: middle;
}

thead {
  background-color: #6E9489;
  color: white;
}

h4 {
  font-weight: 600;
}
</style>
