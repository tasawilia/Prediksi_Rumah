<!-- eslint-disable vue/multi-word-component-names -->

<template>
  <body>
    <div :class="['wrapper', { 'no-sidebar': $route.meta.noSidebar }]">
      <!-- Sidebar: hanya muncul jika bukan login -->
      <div
        class="sidebar"
        data-color="white"
        data-active-color="danger"
        v-if="!$route.meta.noSidebar"
      >
        <div class="logo">
          <a href="" class="simple-text logo-mini">
            <div class="logo-image-small">
              <img src="/assets/img/LogoApk.png">
            </div>
          </a>
          <a href="" class="simple-text logo-normal">
            EstiHome
          </a>
        </div>
        <Sidebar />
      </div>

      <div class="main-panel">
        <Nav v-if="!$route.meta.noNavbar" />
        <router-view />
        <Footer v-if="!$route.meta.noFooter" />
      </div>
    </div>
  </body>
</template>


<script>

// Import komponen
import Nav from "./components/Nav.vue";
import Sidebar from "./components/Sidebar.vue";
import Footer from "./components/Footer.vue";

export default {
  name: 'App',
  components: {
    Nav,
    Sidebar,
    Footer,
  },
};
</script>


<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  color: #2c3e50;
}

nav {
  padding: 30px;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #0c8353;
}

/* Hilangkan padding kiri saat tidak ada sidebar */
.wrapper.no-sidebar .main-panel {
  margin-left: 0 !important;
  width: 100% !important;
}

/* Atasi kemungkinan sidebar masih berpengaruh secara layout */
.wrapper.no-sidebar {
  display: flex;
}

.wrapper.no-sidebar .sidebar {
  display: none;
  width: 0;
}

</style>
