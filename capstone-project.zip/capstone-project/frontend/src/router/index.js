import { createRouter, createWebHistory } from 'vue-router'
//import HomeView from '../views/HomeView.vue'
import PrediksiHarga from '@/views/PrediksiHarga.vue'
import Dashboard from '@/views/Dashboard.vue'
import RiwayatPrediksi from '@/views/RiwayatPrediksi.vue'
import Profil from '@/views/Profil.vue'
import EditProfil from '@/views/EditProfil.vue'
import Login from '@/views/Login.vue'
import Registrasi from '@/views/Registrasi.vue'
import NotFound from '@/views/NotFound.vue'

const routes = [
  {
    path: '/',
    name: 'Login',
    component: Login,
    meta: { noNavbar: true, noSidebar: true, noFooter: true }
  },
  {
    path: '/registrasi',
    name: 'Registrasi',
    component: Registrasi,
    meta: { noNavbar: true, noSidebar: true, noFooter: true }
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: Dashboard,
    meta: { requiresAuth: true }
  },
  {
    path: '/prediksiharga',
    name: 'PrediksiHarga',
    component: PrediksiHarga,
    meta: { requiresAuth: true }
  },
  {
    path: '/riwayatprediksi',
    name: 'RiwayatPrediksi',
    component: RiwayatPrediksi,
    meta: { requiresAuth: true }
  },
  {
    path: '/profil',
    name: 'Profil',
    component: Profil,
    meta: { requiresAuth: true }
  },
  {
    path: '/editprofil',
    name: 'EditProfil',
    component: EditProfil,
    meta: { requiresAuth: true }
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: NotFound,
    meta: { noNavbar: true, noSidebar: true, noFooter: true }
  }
]


const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token')

  if (to.meta.requiresAuth && !token) {
    // Belum login dan mau akses halaman yg butuh login
    next({ path: '/' })
  } else if (to.path === '/' && token) {
    // Sudah login, jangan bisa ke halaman login lagi
    next({ path: '/dashboard' })
  } else {
    next() // Lanjutkan navigasi
  }
})

export default router
