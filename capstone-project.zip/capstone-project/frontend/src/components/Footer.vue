<!-- eslint-disable vue/multi-word-component-names  -->
<template>
    <footer class="footer footer-black footer-white ">
      <div class="container-fluid">
        <div class="row">
          <div class="credits ml-auto">
            <span class="copyright">
              ©2025 by Mai Tasa Wilia
            </span>
          </div>
        </div>
      </div>
    </footer>
  </template>
  