<!-- eslint-disable vue/multi-word-component-names -->
<template>
  <div class="sidebar-wrapper">
    <ul class="nav">
      <li :class="{ active: isActive('/dashboard') }">
        <a href="/dashboard">
          <i class="nc-icon nc-layout-11"></i>
          <p>Dashboard</p>
        </a>
      </li>
      <li :class="{ active: isActive('/prediksiharga') }">
        <a href="/prediksiharga">
          <i class="nc-icon nc-chart-bar-32"></i>
          <p>Prediksi Harga</p>
        </a>
      </li>
      <li :class="{ active: isActive('/riwayatprediksi') }">
        <a href="/riwayatprediksi">
          <i class="nc-icon nc-refresh-69"></i>
          <p>Riwayat Prediksi</p>
        </a>
      </li>
      <li :class="{ active: isActive('/profil') }">
        <a href="/profil">
          <i class="nc-icon nc-single-02"></i>
          <p>Profil</p>
        </a>
      </li>
    </ul>

    <!-- Logout tetap di bawah -->
    <div class="logout">
      <a @click="logout">
        <i class="nc-icon nc-button-power"></i>
        <span>Logout</span>
      </a>
    </div>
  </div>
</template>

<script>
import Swal from 'sweetalert2'
export default {
  methods: {
    isActive(path) {
      return this.$route.path === path;
    },
    logout() {
      Swal.fire({
        title: 'Konfirmasi Logout',
        text: 'Apakah Anda yakin ingin keluar?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#6E9489',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Logout',
        cancelButtonText: 'Batal',
        width: '320px',
        customClass: {
          popup: 'custom-swal-popup',
          title: 'custom-swal-title',
          confirmButton: 'custom-logout-confirm-btn',
          cancelButton: 'custom-logout-cancel-btn',
        }
      }).then((result) => {
        if (result.isConfirmed) {
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          this.$router.push('/');
        }
      })
    }
  }
}
</script>

<style>
.custom-logout-confirm-btn:focus,
.custom-logout-cancel-btn:focus {
  outline: none !important;
  box-shadow: none !important;
}

.custom-swal-popup {
  font-size: 13px !important;
}

.custom-swal-title {
  font-size: 16px !important;
}

.custom-logout-confirm-btn {
  background-color: #d33 !important;
  color: white !important;
  font-size: 13px !important;
  padding: 6px 14px !important;
  border-radius: 4px !important;
}

.custom-logout-cancel-btn {
  background-color: #6E9489 !important;
  color: white !important;
  font-size: 13px !important;
  padding: 6px 14px !important;
  border-radius: 4px !important;
  margin-left: 8px;
}
</style>

<style scoped>
.sidebar-wrapper {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100vh;
}

.active a {
  background-color: #0850349e !important;
  color: white !important;
  font-weight: bold;
  border-radius: 10px;
  padding-left: 15px;
  transition: background-color 0.3s;
}

.active a .nc-icon {
  color: white !important;
}

.logout {
  margin-top: auto;
  padding: 10px;
  text-align: center;
}

.logout a {
  display: flex;
  align-items: center;
  justify-content: center;
  color: #333;
  text-decoration: none;
  padding: 10px;
  transition: background-color 0.3s ease, color 0.3s ease;
}

.logout a:hover {
  background-color: #6E9489;
  color: #fff;
}

.logout a i {
  margin-right: 8px;
  font-size: 18px;
}

.logout a span {
  font-size: 16px;
  font-weight: 600;
}
</style>
